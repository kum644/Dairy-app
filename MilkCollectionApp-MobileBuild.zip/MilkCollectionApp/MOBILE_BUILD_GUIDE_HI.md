# मोबाइल से APK बनाने की गाइड

इस ZIP में `.github/workflows/android-build.yml` जोड़ा गया है। यह GitHub Actions के cloud runner पर Android SDK/Gradle से Debug APK बनाने की कोशिश करेगा।

## कदम
1. मोबाइल ब्राउज़र में https://github.com खोलें और साइन इन/खाता बनाएँ।
2. `New repository` चुनें, नाम `milk-collection-app` रखें और repository बनाएँ। इसे private रखना चाहें तो private चुनें।
3. ZIP को फोन में extract करें। उसके अंदर `MilkCollectionApp` फ़ोल्डर की सभी फ़ाइलें (जिसमें `.github` भी शामिल है) repository में upload करें। यदि मोबाइल साइट पर folder upload उपलब्ध न हो, तो GitHub का browser upload विकल्प इस्तेमाल करें; hidden `.github` फ़ोल्डर छूटना नहीं चाहिए।
4. फ़ाइलें `main` branch में commit करें। GitHub → Actions खोलें और `Build Milk Collection APK` workflow चुनें। `Run workflow` दबाएँ, यदि आवश्यक हो।
5. Run पूरा होने पर build job खोलें। यदि सफल हो तो Artifacts में `milk-collection-apk` डाउनलोड करें और ZIP के अंदर `app-debug.apk` मिलेगा।

## जरूरी बातें
- यह workflow build की कोशिश करेगा; सफल APK की गारंटी नहीं है। Kotlin/Gradle त्रुटि आए तो Actions के log से ठीक करनी होगी।
- `.github/workflows/android-build.yml` अपलोड होना जरूरी है।
- Firebase के लिए अभी वैध `google-services.json` और Firebase configuration अलग से आवश्यक हो सकती है।
- Debug APK परीक्षण के लिए है, Play Store release के लिए signed release build नहीं।
- GitHub Actions की उपलब्धता/limits आपके खाते और GitHub की वर्तमान शर्तों पर निर्भर हैं।
