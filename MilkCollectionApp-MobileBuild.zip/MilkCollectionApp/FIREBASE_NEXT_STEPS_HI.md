# Firebase + Owner/Employee login — अगला आवश्यक चरण

इस समय app local-only है। सुरक्षित login और multi-device sync जोड़ने के लिए:

1. Firebase Console में नया project बनाएं और Android app ID ठीक `in.milkcollection.app` रखें।
2. Authentication में Email/Password enable करें।
3. Firestore Database बनाएं; production mode में रखें।
4. Owner और employee के लिए अलग Firebase users बनाएं। Role को client-side hardcode न करें; server-controlled user/role document और Firestore Security Rules से enforce करें।
5. Android app में Firebase Auth login/logout UI, role fetch, owner-only farmer/employee management, employee permissions, Room outbox, retryable sync worker, conflict policy और per-business Firestore paths implement करने होंगे।
6. Rules को Firebase Emulator Suite में test करें: employee को owner-only actions न मिलें; दूसरे business का डेटा read/write न हो; unauthenticated writes block हों।
7. Google-provided `google-services.json` को `app/` में रखें और Google Services Gradle plugin enable करें। फिर real device पर online/offline, sign-in, sync retry, duplicate conflict और restore tests करें।

कृपया Firebase service-account private key या कोई password चैट में साझा न करें। Android client में service-account key कभी embed नहीं करनी चाहिए।
