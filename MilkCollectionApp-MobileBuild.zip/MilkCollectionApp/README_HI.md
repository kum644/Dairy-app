# Milk Collection — Native Android (Kotlin)

यह Android Studio के लिए Kotlin + Jetpack Compose प्रोजेक्ट है। अभी यह **offline/local-first development build** है; इसे production-ready या Android SDK से compile-verified APK न मानें।

## इस source version में मौजूद सुविधाएँ
- किसान जोड़ना: नाम, मोबाइल, स्थिर ₹/kg रेट
- तारीख के अनुसार सुबह/शाम दूध एंट्री; मात्रा × fixed rate से रकम
- उसी किसान/तारीख/सेशन की एंट्री दोबारा सेव करने पर duplicate बनाने के बजाय update
- भुगतान दर्ज करना और चुनी तारीख के भुगतान देखना
- क्लिक करके तारीख चुनना
- होम स्क्रीन पर कुल दूध/भुगतान का हिसाब लगाकर कुल बकाया दिखाना
- किसान-विशेष 7 दिन, 15 दिन और कैलेंडर-महीने (1 से आखिरी तारीख) की PDF
- PDF में opening balance, अवधि का दूध, भुगतान और closing balance; Android share sheet से PDF साझा करना
- हिंदी/अंग्रेज़ी label toggle
- JSON backup export और restore; restore से पहले confirmation और data validation
- Room local database: इंटरनेट के बिना स्थानीय रिकॉर्ड सहेजना

## चलाने का तरीका
1. Android Studio में `MilkCollectionApp` फ़ोल्डर खोलें।
2. JDK 17, Android SDK Platform 35 और Android Gradle Plugin-compatible Gradle उपलब्ध रखें।
3. Gradle Sync करें, फिर emulator/Android फोन पर Run करें।
4. Debug APK बनाने के लिए Android Studio में **Build > Build APK(s)** चुनें या SDK/Gradle सही होने पर `./gradlew assembleDebug` चलाएँ।

## महत्वपूर्ण — अभी क्या बाकी है
- इस वातावरण में Android SDK, `android.jar`, Gradle executable/wrapper और Gradle dependency cache उपलब्ध नहीं थे। इसलिए वास्तविक Android compile, APK निर्माण, फोन पर install/run परीक्षण **नहीं हुआ**। XML parse और Kotlin syntax-only check हुए हैं, वे Android build verification का विकल्प नहीं हैं।
- Firebase Authentication, owner/employee role enforcement, Firestore sync queue/conflict handling और Firestore security rules अभी लागू/सत्यापित नहीं हैं। Firebase dependencies मौजूद हैं, पर इस source version में cloud sync चालू नहीं है।
- Firebase चालू करने के लिए Firebase Console में project, Android app ID `in.milkcollection.app`, Authentication, Firestore और restrictive security rules configure करने होंगे। केवल `google-services.json` जोड़ देना पर्याप्त नहीं; login/roles/sync implementation और end-to-end test भी करना होगा।
- PDF में बहुत अधिक रिकॉर्ड होने पर multi-page pagination अभी नहीं है; लंबे महीने की रिपोर्ट में नीचे की पंक्तियाँ कट सकती हैं।
- डेटा में किसानों के नाम/मोबाइल/हिसाब हो सकते हैं। Backup file को सुरक्षित रखें। Restore चुने गए backup से मौजूदा local डेटा बदल देता है।

## हिसाब
- Milk amount = weight kg × entry-time fixed rate.
- Opening balance = चुनी अवधि से पहले का कुल दूध − चुनी अवधि से पहले के भुगतान.
- Closing balance = opening balance + अवधि का दूध − अवधि के भुगतान.
- मासिक PDF में चालू कैलेंडर महीने की 1 तारीख से आखिरी तारीख तक की अवधि चुनी जाती है।

**कृपया इसे असली डेयरी का हिसाब रखने के लिए तब तक अकेले इस्तेमाल न करें जब तक Android build, restore, हिसाब और Firebase/role security का परीक्षण पूरा न हो।**
