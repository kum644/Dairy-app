package `in`.milkcollection.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmerDao {
    @Query("SELECT * FROM farmers WHERE active = 1 ORDER BY name") fun all(): Flow<List<Farmer>>
    @Query("SELECT * FROM farmers WHERE id = :id LIMIT 1") suspend fun byId(id: String): Farmer?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(farmer: Farmer)
    @Query("SELECT * FROM farmers") suspend fun exportAll(): List<Farmer>
    @Query("DELETE FROM farmers") suspend fun clear()
}

@Dao
interface MilkDao {
    @Query("SELECT * FROM milk_entries ORDER BY date DESC, session") fun observeAll(): Flow<List<MilkEntry>>
    @Query("SELECT * FROM milk_entries WHERE date = :date ORDER BY session, farmerId") fun byDate(date: String): Flow<List<MilkEntry>>
    @Query("SELECT * FROM milk_entries WHERE farmerId = :farmerId AND date BETWEEN :from AND :to ORDER BY date, session") suspend fun byFarmerRange(farmerId: String, from: String, to: String): List<MilkEntry>
    @Query("SELECT * FROM milk_entries WHERE date BETWEEN :from AND :to ORDER BY date, session") suspend fun range(from: String, to: String): List<MilkEntry>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(entry: MilkEntry)
    @Query("SELECT * FROM milk_entries") suspend fun exportAll(): List<MilkEntry>
    @Query("SELECT * FROM milk_entries WHERE farmerId = :farmerId ORDER BY date, session") suspend fun allForFarmer(farmerId: String): List<MilkEntry>
    @Query("SELECT * FROM milk_entries WHERE farmerId = :farmerId AND date < :before ORDER BY date, session") suspend fun beforeDate(farmerId: String, before: String): List<MilkEntry>
    @Query("SELECT * FROM milk_entries WHERE farmerId = :farmerId AND date = :date AND session = :session LIMIT 1") suspend fun findSession(farmerId: String, date: String, session: String): MilkEntry?
    @Query("DELETE FROM milk_entries") suspend fun clear()
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE date = :date ORDER BY date DESC") fun byDate(date: String): Flow<List<Payment>>
    @Query("SELECT * FROM payments ORDER BY date DESC") fun observeAll(): Flow<List<Payment>>
    @Query("SELECT * FROM payments WHERE farmerId = :farmerId AND date BETWEEN :from AND :to ORDER BY date") suspend fun byFarmerRange(farmerId: String, from: String, to: String): List<Payment>
    @Query("SELECT * FROM payments WHERE date BETWEEN :from AND :to ORDER BY date") suspend fun range(from: String, to: String): List<Payment>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(payment: Payment)
    @Query("SELECT * FROM payments") suspend fun exportAll(): List<Payment>
    @Query("SELECT * FROM payments WHERE farmerId = :farmerId ORDER BY date") suspend fun allForFarmer(farmerId: String): List<Payment>
    @Query("SELECT * FROM payments WHERE farmerId = :farmerId AND date < :before ORDER BY date") suspend fun beforeDate(farmerId: String, before: String): List<Payment>
    @Query("DELETE FROM payments") suspend fun clear()
}

@Database(entities = [Farmer::class, MilkEntry::class, Payment::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun farmers(): FarmerDao
    abstract fun milk(): MilkDao
    abstract fun payments(): PaymentDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "milk_collection.db").build().also { INSTANCE = it }
        }
    }
}
