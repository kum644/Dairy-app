package `in`.milkcollection.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import `in`.milkcollection.app.data.*
import `in`.milkcollection.app.util.BackupUtils
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID
import java.util.Locale
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

private enum class Tab { HOME, FARMERS, COLLECTION, PAYMENTS, CALENDAR, REPORTS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(db: AppDatabase, context: android.content.Context) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(Tab.HOME) }
    var lang by remember { mutableStateOf("hi") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val farmers by db.farmers().all().collectAsState(initial = emptyList())
    val entries by db.milk().byDate(date).collectAsState(initial = emptyList())
    val allMilk by db.milk().observeAll().collectAsState(initial = emptyList())
    val allPayments by db.payments().observeAll().collectAsState(initial = emptyList())
    val paymentsToday by db.payments().byDate(date).collectAsState(initial = emptyList())
    var message by remember { mutableStateOf("") }
    val hi = lang == "hi"
    fun tr(h: String, e: String) = if (hi) h else e

    Scaffold(topBar = {
        TopAppBar(title = { Text(tr("दूध कलेक्शन", "Milk Collection")) }, actions = {
            TextButton(onClick = { lang = if (hi) "en" else "hi" }) { Text(if (hi) "EN" else "हिंदी") }
        })
    }, bottomBar = {
        NavigationBar {
            listOf(Tab.HOME, Tab.FARMERS, Tab.COLLECTION, Tab.PAYMENTS, Tab.CALENDAR, Tab.REPORTS).forEach { t ->
                val label = when(t) { Tab.HOME -> tr("होम","Home"); Tab.FARMERS -> tr("किसान","Farmers"); Tab.COLLECTION -> tr("कलेक्शन","Milk"); Tab.PAYMENTS -> tr("भुगतान","Pay"); Tab.CALENDAR -> tr("कैलेंडर","Calendar"); Tab.REPORTS -> tr("रिपोर्ट","Reports") }
                NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(when(t) { Tab.HOME -> Icons.Default.Home; Tab.FARMERS -> Icons.Default.People; Tab.COLLECTION -> Icons.Default.WaterDrop; Tab.PAYMENTS -> Icons.Default.Payments; Tab.CALENDAR -> Icons.Default.CalendarMonth; Tab.REPORTS -> Icons.Default.Assessment }, contentDescription = label) }, label = { Text(label) })
            }
        }
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when(tab) {
                Tab.HOME -> {
                    Text(tr("आज का सारांश", "Today's Summary"), style = MaterialTheme.typography.headlineSmall)
                    SummaryCard(tr("किसान", "Farmers"), farmers.size.toString())
                    SummaryCard(tr("आज का दूध", "Today's milk"), "%.2f kg".format(entries.sumOf { it.weightKg }))
                    SummaryCard(tr("आज की रकम", "Today's amount"), "₹%.2f".format(entries.sumOf { it.amount }))
                    SummaryCard(tr("कुल बकाया", "Total outstanding"), "₹%.2f".format(allMilk.sumOf { it.amount } - allPayments.sumOf { it.amount }))
                    Text(tr("डेटा फोन में ऑफलाइन सेव होता है। Firebase सिंक चालू करने से पहले Firebase प्रोजेक्ट जोड़ें।", "Data is stored offline on this phone. Add your Firebase project before enabling cloud sync."), style = MaterialTheme.typography.bodySmall)
                }
                Tab.FARMERS -> FarmerScreen(db, farmers, tr("किसान जोड़ें", "Add farmer"), tr("नाम", "Name"), tr("मोबाइल", "Mobile"), tr("रेट ₹/kg", "Rate ₹/kg"), message = { message = it })
                Tab.COLLECTION -> CollectionScreen(db, farmers, date, entries, tr("दूध एंट्री", "Milk entry"), tr("वजन kg", "Weight kg"), tr("सुबह", "Morning"), tr("शाम", "Evening"), message = { message = it })
                Tab.PAYMENTS -> PaymentScreen(db, farmers, date, paymentsToday, tr("भुगतान दर्ज करें", "Record payment"), message = { message = it })
                Tab.CALENDAR -> CalendarScreen(date, onDate = { date = it }, title = tr("तारीख चुनें", "Choose date"))
                Tab.REPORTS -> ReportsScreen(context, db, farmers, tr("रिपोर्ट और PDF", "Reports & PDF"), message = { message = it })
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable private fun SummaryCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Spacer(Modifier.width(12.dp)); Text(value, style = MaterialTheme.typography.titleMedium) } }
}

@Composable private fun FarmerScreen(db: AppDatabase, farmers: List<Farmer>, addLabel: String, nameLabel: String, mobileLabel: String, rateLabel: String, message: (String)->Unit) {
    var name by remember { mutableStateOf("") }; var mobile by remember { mutableStateOf("") }; var rate by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Text(addLabel, style = MaterialTheme.typography.titleLarge)
    OutlinedTextField(name, { name = it }, label = { Text(nameLabel) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(mobile, { mobile = it }, label = { Text(mobileLabel) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(rate, { rate = it }, label = { Text(rateLabel) }, modifier = Modifier.fillMaxWidth())
    Button(onClick = {
        val r = rate.toDoubleOrNull()
        if (name.isBlank() || r == null || r < 0) message("नाम और सही रेट भरें / Enter name and valid rate")
        else scope.launch { db.farmers().save(Farmer(UUID.randomUUID().toString(), name.trim(), mobile.trim(), r)); name=""; mobile=""; rate=""; message("किसान सेव हुआ / Farmer saved") }
    }, modifier = Modifier.fillMaxWidth()) { Text(addLabel) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) { items(farmers) { f -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text("${f.name} • ${f.id.take(8)}", style = MaterialTheme.typography.titleMedium); Text("${f.mobile}  |  ₹%.2f/kg".format(f.ratePerKg)) } } } }
}

@Composable private fun CollectionScreen(db: AppDatabase, farmers: List<Farmer>, date: String, entries: List<MilkEntry>, title: String, weightLabel: String, morning: String, evening: String, message: (String)->Unit) {
    var selected by remember(farmers) { mutableStateOf(farmers.firstOrNull()?.id.orEmpty()) }
    var weight by remember { mutableStateOf("") }; var session by remember { mutableStateOf("MORNING") }
    val scope = rememberCoroutineScope()
    Text("$title • $date", style = MaterialTheme.typography.titleLarge)
    if (farmers.isEmpty()) Text("पहले किसान टैब में किसान जोड़ें / Add a farmer first")
    else {
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(value = farmers.firstOrNull { it.id == selected }?.name ?: "किसान चुनें", onValueChange = {}, readOnly = true, label = { Text("किसान / Farmer") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { farmers.forEach { f -> DropdownMenuItem(text = { Text("${f.name} — ₹${f.ratePerKg}/kg") }, onClick = { selected = f.id; expanded = false }) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(session == "MORNING", { session = "MORNING" }, label = { Text(morning) }); FilterChip(session == "EVENING", { session = "EVENING" }, label = { Text(evening) }) }
        OutlinedTextField(weight, { weight = it }, label = { Text(weightLabel) }, modifier = Modifier.fillMaxWidth())
        val amount = (weight.toDoubleOrNull() ?: 0.0) * (farmers.firstOrNull { it.id == selected }?.ratePerKg ?: 0.0)
        Text("कुल रकम / Amount: ₹%.2f".format(amount))
        Button(onClick = { val kg = weight.toDoubleOrNull(); val f = farmers.firstOrNull { it.id == selected }; if (kg == null || kg <= 0 || f == null) message("सही किसान और वजन चुनें / Select farmer and valid weight") else scope.launch { val existing = db.milk().findSession(f.id, date, session); db.milk().save(MilkEntry(existing?.id ?: UUID.randomUUID().toString(), f.id, date, session, kg, f.ratePerKg, kg*f.ratePerKg, existing?.note.orEmpty())); weight=""; message(if (existing == null) "कलेक्शन सेव हुआ / Collection saved" else "एंट्री अपडेट हुई / Entry updated") } }, modifier = Modifier.fillMaxWidth()) { Text("सेव करें / Save") }
    }
    Text("इस तारीख की एंट्री / Entries for date", style = MaterialTheme.typography.titleMedium)
    LazyColumn { items(entries) { e -> val f = farmers.firstOrNull { it.id == e.farmerId }; Text("${f?.name ?: e.farmerId.take(8)} • ${if(e.session=="MORNING") morning else evening} • ${e.weightKg} kg • ₹%.2f".format(e.amount)); Divider() } }
}

@Composable private fun PaymentScreen(db: AppDatabase, farmers: List<Farmer>, date: String, paymentsToday: List<Payment>, title: String, message: (String)->Unit) {
    var selected by remember(farmers) { mutableStateOf(farmers.firstOrNull()?.id.orEmpty()) }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; val scope = rememberCoroutineScope(); var expanded by remember { mutableStateOf(false) }
    Text("$title • $date", style = MaterialTheme.typography.titleLarge)
    if (farmers.isEmpty()) Text("पहले किसान जोड़ें / Add a farmer first") else {
        ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(farmers.firstOrNull { it.id == selected }?.name ?: "किसान चुनें", {}, readOnly = true, label = { Text("किसान / Farmer") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth()); ExposedDropdownMenu(expanded, { expanded=false }) { farmers.forEach { f -> DropdownMenuItem(text={Text(f.name)}, onClick={selected=f.id;expanded=false}) } } }
        OutlinedTextField(amount, { amount=it }, label={Text("भुगतान राशि ₹ / Payment ₹")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(note, { note=it }, label={Text("नोट / Note (optional)")}, modifier=Modifier.fillMaxWidth())
        Button(onClick={ val a=amount.toDoubleOrNull(); if(a==null||a<=0) message("सही राशि भरें / Enter valid amount") else scope.launch { db.payments().save(Payment(UUID.randomUUID().toString(), selected, date, a, note)); amount=""; note=""; message("भुगतान सेव हुआ / Payment saved") } }, modifier=Modifier.fillMaxWidth()) { Text("भुगतान सेव करें / Save payment") }
    }
    Text("इस तारीख के भुगतान / Payments on $date", style=MaterialTheme.typography.titleMedium)
    LazyColumn { items(paymentsToday) { pay -> val f = farmers.firstOrNull { it.id == pay.farmerId }; Text("${f?.name ?: pay.farmerId.take(8)} • ₹%.2f • ${pay.note}".format(pay.amount)); Divider() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun CalendarScreen(date: String, onDate: (String)->Unit, title: String) {
    var shown by remember { mutableStateOf(false) }; val state = rememberDatePickerState(initialSelectedDateMillis = java.time.LocalDate.parse(date).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli())
    Text(title, style=MaterialTheme.typography.titleLarge)
    OutlinedButton(onClick={shown=true}, modifier=Modifier.fillMaxWidth()) { Text("📅 $date  •  तारीख बदलें / Change date") }
    if (shown) DatePickerDialog(onDismissRequest={shown=false}, confirmButton={ TextButton(onClick={ state.selectedDateMillis?.let { onDate(java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneOffset.UTC).toLocalDate().toString()) }; shown=false }) { Text("चुनें / Select") } }, dismissButton={ TextButton(onClick={shown=false}) { Text("रद्द / Cancel") } }) { DatePicker(state) }
    Text("चुनी गई तारीख की कलेक्शन और भुगतान एंट्री संबंधित टैब में दिखाई देंगी। / Selected-date records are shown in the relevant tabs.")
}

@Composable private fun ReportsScreen(context: Context, db: AppDatabase, farmers: List<Farmer>, title: String, message: (String)->Unit) {
    var selected by remember(farmers) { mutableStateOf(farmers.firstOrNull()?.id.orEmpty()) }
    var days by remember { mutableIntStateOf(7) }
    var expanded by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { BackupUtils.export(context, db, uri) }.onSuccess { message("Backup सेव हुआ / Backup saved") }.onFailure { message("Backup असफल / Backup failed: ${it.message}") } }
    }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching { BackupUtils.restore(context, db, uri) }.onSuccess { message("Restore पूरा हुआ / Restore complete") }.onFailure { message("Restore असफल / Restore failed: ${it.message}") } }
    }
    Text(title, style=MaterialTheme.typography.titleLarge)
    if (farmers.isEmpty()) Text("रिपोर्ट बनाने के लिए पहले किसान जोड़ें / Add farmers first") else {
        ExposedDropdownMenuBox(expanded, {expanded=!expanded}) {
            OutlinedTextField(farmers.firstOrNull{it.id==selected}?.name ?: "किसान", {}, readOnly=true, label={Text("किसान / Farmer")}, trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)}, modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded,{expanded=false}) { farmers.forEach { f -> DropdownMenuItem(text={Text(f.name)},onClick={selected=f.id;expanded=false}) } }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf(7,15,30).forEach { d -> FilterChip(selected=days==d,onClick={days=d},label={Text(if(d==30) "मासिक / Monthly" else "$d दिन / days")}) } }
        Text(if(days==30) "मासिक रिपोर्ट कैलेंडर महीने (1 से आखिरी तारीख) की होगी।" else "अवधि: आज सहित पिछले $days दिन / Last $days days including today")
        Button(onClick={scope.launch {
            try {
                val today=LocalDate.now()
                val from=if(days==30) today.withDayOfMonth(1).toString() else today.minusDays((days-1).toLong()).toString()
                val to=if(days==30) today.withDayOfMonth(today.lengthOfMonth()).toString() else today.toString()
                val f=farmers.first{it.id==selected}
                val milk=db.milk().byFarmerRange(selected,from,to); val pays=db.payments().byFarmerRange(selected,from,to)
                val beforeMilk=db.milk().beforeDate(selected,from).sumOf { it.amount }; val beforePaid=db.payments().beforeDate(selected,from).sumOf { it.amount }
                val pdf=makePdf(context, f, from, to, milk, pays, beforeMilk-beforePaid)
                message("PDF बनाया गया: ${pdf.absolutePath}")
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdf)
                val share = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                context.startActivity(Intent.createChooser(share, "PDF बिल शेयर करें / Share farmer bill"))
            } catch(e: Exception) { message("PDF नहीं बना: ${e.message}") }
        } }, modifier=Modifier.fillMaxWidth()) { Text("PDF बिल बनाएं / Generate PDF") }
    }
    Divider()
    Text("बैकअप / Backup", style=MaterialTheme.typography.titleMedium)
    Text("JSON backup में किसान, कलेक्शन और भुगतान शामिल हैं। Restore मौजूदा डेटा को बदल देगा।")
    Button(onClick={ createBackup.launch("milk_collection_backup_${LocalDate.now()}.json") }, modifier=Modifier.fillMaxWidth()) { Text("Backup export करें / Export backup") }
    OutlinedButton(onClick={confirmRestore=true}, modifier=Modifier.fillMaxWidth()) { Text("Backup restore करें / Restore backup") }
    if (confirmRestore) AlertDialog(onDismissRequest={confirmRestore=false}, title={Text("Restore data?")}, text={Text("यह फोन का मौजूदा किसान, कलेक्शन और भुगतान डेटा हटाकर चुने गए backup से बदलेगा। पहले वर्तमान डेटा का backup लें।")}, confirmButton={TextButton(onClick={confirmRestore=false; openBackup.launch(arrayOf("application/json", "text/json", "*/*"))}) { Text("आगे बढ़ें / Continue") }}, dismissButton={TextButton(onClick={confirmRestore=false}) { Text("रद्द / Cancel") }})
    Text("महत्वपूर्ण: Cloud sync और मालिक/कर्मचारी सुरक्षित login के लिए आपका Firebase project और security rules configure करना जरूरी है।")
}

// Multi-page PDF helper. All rows are kept; a new page starts before the footer area.
private fun makePdf(context: Context, farmer: Farmer, from: String, to: String, milk: List<MilkEntry>, payments: List<Payment>, openingBalance: Double): File {
    val doc = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val left = 36f
    val bottom = 790f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var pageNumber = 0
    var page: PdfDocument.Page? = null
    var y = 0f

    fun startPage() {
        pageNumber += 1
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        y = 48f
        paint.textSize = 20f
        page!!.canvas.drawText("MILK COLLECTION - FARMER BILL", left, y, paint)
        y += 32f
        paint.textSize = 12f
        page!!.canvas.drawText("Farmer: ${farmer.name} | ID: ${farmer.id}", left, y, paint); y += 20f
        page!!.canvas.drawText("Mobile: ${farmer.mobile} | Rate: Rs ${farmer.ratePerKg}/kg", left, y, paint); y += 20f
        page!!.canvas.drawText("Period: $from to $to", left, y, paint); y += 26f
        paint.textSize = 11f
        page!!.canvas.drawText("DATE          SESSION          KG                 AMOUNT", left, y, paint); y += 18f
    }
    fun finishPage() {
        val current = page ?: return
        paint.textSize = 9f
        current.canvas.drawText("Page $pageNumber", pageWidth - 75f, pageHeight - 22f, paint)
        doc.finishPage(current)
        page = null
    }
    fun line(text: String, size: Float = 11f) {
        if (page == null) startPage()
        if (y > bottom) { finishPage(); startPage() }
        paint.textSize = size
        page!!.canvas.drawText(text.take(100), left, y, paint)
        y += size + 8f
    }

    startPage()
    milk.forEach { entry ->
        line("${entry.date}       ${entry.session}          ${"%.2f".format(Locale.US, entry.weightKg)} kg          Rs ${"%.2f".format(Locale.US, entry.amount)}")
    }
    val milkTotal = milk.sumOf { it.amount }
    val paid = payments.sumOf { it.amount }
    y += 12f
    line("Total milk: %.2f kg".format(Locale.US, milk.sumOf { it.weightKg }))
    line("Milk amount: Rs %.2f".format(Locale.US, milkTotal))
    line("Opening balance: Rs %.2f".format(Locale.US, openingBalance))
    line("Payments in period: Rs %.2f".format(Locale.US, paid))
    line("Closing balance: Rs %.2f".format(Locale.US, openingBalance + milkTotal - paid))
    line("Generated by Milk Collection App")
    finishPage()

    val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "MilkBills").apply { mkdirs() }
    val file = File(dir, "bill_${farmer.id.take(8)}_${from}_$to.pdf")
    FileOutputStream(file).use { doc.writeTo(it) }
    doc.close()
    return file
}
