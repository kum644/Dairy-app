package `in`.milkcollection.app.util

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import `in`.milkcollection.app.data.AppDatabase
import `in`.milkcollection.app.data.Farmer
import `in`.milkcollection.app.data.MilkEntry
import `in`.milkcollection.app.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** JSON backup is local/offline; exported files may contain personal farmer data. */
object BackupUtils {
    suspend fun export(context: Context, db: AppDatabase, uri: Uri) = withContext(Dispatchers.IO) {
        val root = JSONObject().put("format", "milk-collection-backup").put("version", 1)
        root.put("farmers", JSONArray().apply { db.farmers().exportAll().forEach { put(it.toJson()) } })
        root.put("milkEntries", JSONArray().apply { db.milk().exportAll().forEach { put(it.toJson()) } })
        root.put("payments", JSONArray().apply { db.payments().exportAll().forEach { put(it.toJson()) } })
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(root.toString(2)) }
            ?: error("Backup file open नहीं हो सकी")
    }

    suspend fun restore(context: Context, db: AppDatabase, uri: Uri) = withContext(Dispatchers.IO) {
        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Backup file पढ़ी नहीं जा सकी")
        val root = JSONObject(raw)
        require(root.optString("format") == "milk-collection-backup") { "यह Milk Collection backup नहीं है" }
        require(root.optInt("version") == 1) { "Backup version समर्थित नहीं है" }
        val farmers = root.getJSONArray("farmers").mapObjects { it.toFarmer() }
        val milk = root.getJSONArray("milkEntries").mapObjects { it.toMilkEntry() }
        val payments = root.getJSONArray("payments").mapObjects { it.toPayment() }
        val farmerIds = farmers.map { it.id }.toSet()
        require(farmers.all { it.id.isNotBlank() && it.name.isNotBlank() && it.ratePerKg.isFinite() && it.ratePerKg >= 0.0 }) { "Backup में किसान का नाम, ID या रेट गलत है" }
        require(farmerIds.size == farmers.size) { "Backup में किसान ID दोहराई गई है" }
        require(milk.map { it.id }.toSet().size == milk.size && payments.map { it.id }.toSet().size == payments.size) { "Backup में रिकॉर्ड ID दोहराई गई है" }
        require(milk.all { entry ->
            entry.farmerId in farmerIds && validDate(entry.date) && entry.session in setOf("MORNING", "EVENING") &&
                entry.weightKg.isFinite() && entry.weightKg > 0.0 && entry.ratePerKg.isFinite() && entry.ratePerKg >= 0.0 &&
                entry.amount.isFinite() && entry.amount >= 0.0 && kotlin.math.abs(entry.amount - entry.weightKg * entry.ratePerKg) < 0.02
        }) { "Backup में दूध एंट्री गलत है या किसान से जुड़ी नहीं है" }
        require(milk.map { "${it.farmerId}|${it.date}|${it.session}" }.toSet().size == milk.size) { "Backup में एक ही तारीख/सेशन की डुप्लिकेट दूध एंट्री है" }
        require(payments.all { payment -> payment.farmerId in farmerIds && validDate(payment.date) && payment.amount.isFinite() && payment.amount > 0.0 }) { "Backup में भुगतान गलत है या किसान से जुड़ा नहीं है" }
        db.withTransaction {
            db.payments().clear(); db.milk().clear(); db.farmers().clear()
            farmers.forEach { db.farmers().save(it.copy(synced = false)) }
            milk.forEach { db.milk().save(it.copy(synced = false)) }
            payments.forEach { db.payments().save(it.copy(synced = false)) }
        }
    }
}

private fun <T> JSONArray.mapObjects(convert: (JSONObject) -> T): List<T> = (0 until length()).map { convert(getJSONObject(it)) }
private fun JSONObject.toFarmer() = Farmer(getString("id"), getString("name"), optString("mobile"), getDouble("ratePerKg"), optBoolean("active", true), optLong("updatedAt", System.currentTimeMillis()), false)
private fun JSONObject.toMilkEntry() = MilkEntry(getString("id"), getString("farmerId"), getString("date"), getString("session"), getDouble("weightKg"), getDouble("ratePerKg"), getDouble("amount"), optString("note"), optLong("updatedAt", System.currentTimeMillis()), false)
private fun JSONObject.toPayment() = Payment(getString("id"), getString("farmerId"), getString("date"), getDouble("amount"), optString("note"), optLong("updatedAt", System.currentTimeMillis()), false)
private fun Farmer.toJson() = JSONObject().put("id", id).put("name", name).put("mobile", mobile).put("ratePerKg", ratePerKg).put("active", active).put("updatedAt", updatedAt)
private fun MilkEntry.toJson() = JSONObject().put("id", id).put("farmerId", farmerId).put("date", date).put("session", session).put("weightKg", weightKg).put("ratePerKg", ratePerKg).put("amount", amount).put("note", note).put("updatedAt", updatedAt)
private fun Payment.toJson() = JSONObject().put("id", id).put("farmerId", farmerId).put("date", date).put("amount", amount).put("note", note).put("updatedAt", updatedAt)

private fun validDate(value: String): Boolean = runCatching { LocalDate.parse(value).toString() == value }.getOrDefault(false)
