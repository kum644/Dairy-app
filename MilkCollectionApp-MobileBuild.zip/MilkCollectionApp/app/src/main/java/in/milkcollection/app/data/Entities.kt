package `in`.milkcollection.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "farmers")
data class Farmer(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String,
    val ratePerKg: Double,
    val active: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)

@Entity(tableName = "milk_entries")
data class MilkEntry(
    @PrimaryKey val id: String,
    val farmerId: String,
    val date: String, // yyyy-MM-dd
    val session: String, // MORNING or EVENING
    val weightKg: Double,
    val ratePerKg: Double, // snapshot: rate changes won't rewrite history
    val amount: Double,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey val id: String,
    val farmerId: String,
    val date: String,
    val amount: Double,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val synced: Boolean = false
)
